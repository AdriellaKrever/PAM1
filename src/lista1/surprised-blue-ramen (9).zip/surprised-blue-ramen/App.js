import React, { useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

export default function App() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmar, setConfirmar] = useState("");

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.titulo}>Login</Text>

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        autoCapitalize="none"
        autoComplete="email"
        autoCorrect={false}
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        maxLength={8}
        value={senha}
        onChangeText={setSenha}
      />
      <TextInput
style={styles.input}
placeholder="Confirmar senha"
secureTextEntry
maxLength={8}
value={confirmar}
onChangeText={setConfirmar}
/>

      <TouchableOpacity style={styles.botao}>
        <Text style={styles.textoBotao}>Logar</Text>
      </TouchableOpacity>

      <Text>E-mail: {email}</Text>
      <Text>Senha: {senha}</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 20,
  },
  titulo: {
    fontSize: 28,
    textAlign: "center",
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
    borderRadius: 5,
  },
  botao: {
    backgroundColor: "#2196F3",
    padding: 12,
    borderRadius: 5,
    marginBottom: 20,
  },
  textoBotao: {
    color: "#fff",
    textAlign: "center",
    fontWeight: "bold",
  },
});