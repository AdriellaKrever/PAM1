
import React from "react";
import {
  View,
  StatusBar,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
} from "react-native";
export default function App() {
  return (
    <>
      <StatusBar hidden />

      <View style={styles.container}>

        <View style={styles.top}>
          <View style={styles.lime} />
          <View style={styles.aquamarine} />
        </View>

        <View style={styles.teal}>
          <TouchableOpacity
    onPress={() => Alert.alert("Boa noite!")}
  >
    <Image
      source={{
        uri: "https://reactnative.dev/img/tiny_logo.png",
      }}
      style={styles.image}
      resizeMode="contain"
    />
  </TouchableOpacity>
  />
</View>

        <View style={styles.skyblue} />

      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  top: {
    flex: 1,
    flexDirection: "row",
  },

  lime: {
    flex: 1,
    backgroundColor: "lime",
  },

  aquamarine: {
    flex: 1,
    backgroundColor: "aquamarine",
  },

 teal: {
  flex: 1,
  backgroundColor: "teal",

  justifyContent: "center",
  alignItems: "center",
},
  image: {
  flex: 1,
  alignSelf: "center",
  width: 64,
  height: 64,
},

  skyblue: {
    flex: 1,
    backgroundColor: "skyblue",
  },
});