import React, { useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Switch,
  Picker,
} from "react-native";

export default function App() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmar, setConfirmar] = useState("");
  const [logado,setLogado]=useState(false);
  const [tipo, setTipo] = useState("manager");


  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.titulo}>Login</Text>

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        autoCapitalize="none"
        autoComplete="email"
        autoCorrect={false}
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        maxLength={8}
        value={senha}
        onChangeText={setSenha}
      />
      <TextInput
style={styles.input}
placeholder="Confirmar senha"
secureTextEntry
maxLength={8}
value={confirmar}
onChangeText={setConfirmar}
/>

      <TouchableOpacity style={styles.botao}>
        <Text style={styles.textoBotao}>Logar</Text>
      </TouchableOpacity>
<Picker
selectedValue={tipo}
onValueChange={(itemValue)=>setTipo(itemValue)}
>

<Picker.Item label="Administrador" value="admin"/>

<Picker.Item label="Gestor" value="manager"/>

<Picker.Item label="Usuário" value="user"/>

</Picker>

<Text>Tipo: {tipo}</Text>
      
<Switch
trackColor={{ false: "#e77878", true: "#94df83" }}
thumbColor={logado ? "#47eb22" : "#ed1111"}
value={logado}
onValueChange={setLogado}
/>

<Text>{logado ? "Logado" : "Deslogado"}</Text>

      <Text>E-mail: {email}</Text>
      <Text>Senha: {senha}</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 20,
  },
  titulo: {
    fontSize: 28,
    textAlign: "center",
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
    borderRadius: 5,
  },
  botao: {
    backgroundColor: "#2196F3",
    padding: 12,
    borderRadius: 5,
    marginBottom: 20,
  },
  textoBotao: {
    color: "#fff",
    textAlign: "center",
    fontWeight: "bold",
  },
});