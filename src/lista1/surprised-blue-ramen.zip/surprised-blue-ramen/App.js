import React from 'react';
import { View, StatusBar, StyleSheet } from 'react-native';

export default function App() {
  return (
    <>
      <StatusBar hidden />

      <View style={styles.container}>
        <View style={styles.top} />
        <View style={styles.bottom} />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  top: {
    flex: 1,
    backgroundColor: 'crimson',
  },

  bottom: {
    flex: 1,
    backgroundColor: 'salmon',
  },
});