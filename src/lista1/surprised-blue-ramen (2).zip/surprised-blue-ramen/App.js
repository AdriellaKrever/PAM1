import React from "react";
import { View, StatusBar, StyleSheet } from "react-native";

export default function App() {
  return (
    <>
      <StatusBar hidden />

      <View style={styles.container}>

        <View style={styles.top}>
          <View style={styles.lime} />
          <View style={styles.aquamarine} />
        </View>

        <View style={styles.teal} />

        <View style={styles.skyblue} />

      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  top: {
    flex: 1,
    flexDirection: "row",
  },

  lime: {
    flex: 1,
    backgroundColor: "lime",
  },

  aquamarine: {
    flex: 1,
    backgroundColor: "aquamarine",
  },

  teal: {
    flex: 1,
    backgroundColor: "teal",
  },

  skyblue: {
    flex: 1,
    backgroundColor: "skyblue",
  },
});