import React, { useState } from "react";
import {
  SafeAreaView,
  Text,
  TextInput,
  StyleSheet,
} from "react-native";

export default function App() {

  const [nome, setNome] = useState("");
  const [sobrenome, setSobrenome] = useState("");
  const [idade, setidade] = useState("");

  return (
    <SafeAreaView style={styles.container}>

      <Text style={styles.titulo}>
        Cadastro
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite o nome"
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        style={styles.input}
        placeholder="Digite o sobrenome"
        value={sobrenome}
        onChangeText={setSobrenome}
      />
      <TextInput
        style={styles.input}
        placeholder="digite a sua idade"
        value={idade}
        onChangeText={setidade}
      />

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({

  container:{
    flex:1,
    justifyContent:"center",
    padding:20,
  },

  titulo:{
    fontSize:30,
    fontWeight:"bold",
    marginBottom:20,
    textAlign:"center",
  },

  input:{
    borderWidth:1,
    borderColor:"#999",
    borderRadius:8,
    padding:12,
    marginBottom:15,
  }

});