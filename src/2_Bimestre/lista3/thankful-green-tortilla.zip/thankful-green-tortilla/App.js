import React from 'react';
import {
  SafeAreaView,
  View,
  Button,
  Linking,
  Alert,
  StyleSheet,
} from 'react-native';

export default function App() {

  const abrirYoutube = async () => {

    const url = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';

    const podeAbrir = await Linking.canOpenURL(url);

    if (podeAbrir) {
      Linking.openURL(url);
    } else {
      Alert.alert('Erro', 'Não foi possível abrir o YouTube.');
    }

  };

  return (

    <SafeAreaView style={styles.container}>

      <View>

        <Button
          title="Abrir vídeo no YouTube"
          onPress={abrirYoutube}
        />

      </View>

    </SafeAreaView>

  );

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

});