import React, { useEffect, useState } from 'react';

import {
  View,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
  Alert,
  StatusBar,
} from 'react-native';

import * as ImagePicker from 'expo-image-picker';

import { MaterialIcons } from '@expo/vector-icons';

export default function App() {

  const [imagens, setImagens] = useState([]);

  const [temPermissao, setTemPermissao] = useState(false);

  useEffect(() => {

    async function pedirPermissao() {

      const camera =
        await ImagePicker.requestCameraPermissionsAsync();

      const galeria =
        await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (
        camera.status === 'granted' &&
        galeria.status === 'granted'
      ) {

        setTemPermissao(true);

      }

    }

    pedirPermissao();

  }, []);

  async function abrirGaleria() {

    if (!temPermissao) {

      Alert.alert("Sem permissão");

      return;

    }

    let resultado =
      await ImagePicker.launchImageLibraryAsync({

        mediaTypes: ImagePicker.MediaTypeOptions.Images,

        quality: 1,

      });

    if (!resultado.canceled) {

      setImagens([
        ...imagens,
        resultado.assets[0].uri,
      ]);

    }

  }

  async function abrirCamera() {

    if (!temPermissao) {

      Alert.alert("Sem permissão");

      return;

    }

    let resultado =
      await ImagePicker.launchCameraAsync({

        quality: 1,

      });

    if (!resultado.canceled) {

      setImagens([
        ...imagens,
        resultado.assets[0].uri,
      ]);

    }

  }

  function excluirImagem(index) {

    const novaLista = [...imagens];

    novaLista.splice(index, 1);

    setImagens(novaLista);

  }

  return (

    <View style={styles.container}>

      <View style={styles.topo}>

        <TouchableOpacity onPress={abrirGaleria}>

          <MaterialIcons
            name="photo"
            size={35}
            color="deepskyblue"
          />

        </TouchableOpacity>

        <TouchableOpacity onPress={abrirCamera}>

          <MaterialIcons
            name="photo-camera"
            size={35}
            color="deepskyblue"
          />

        </TouchableOpacity>

      </View>

      <ScrollView>

        {

          imagens.map((item, index) => (

            <View
              key={index}
              style={styles.card}
            >

              <TouchableOpacity
                style={styles.fechar}
                onPress={() => excluirImagem(index)}
              >

                <MaterialIcons
                  name="close"
                  size={28}
                  color="red"
                />

              </TouchableOpacity>

              <Image

                source={{ uri: item }}

                style={styles.imagem}

              />

            </View>

          ))

        }

      </ScrollView>

    </View>

  );

}

const styles = StyleSheet.create({

  container: {

    flex:1,

    backgroundColor:'#222',

    paddingTop:StatusBar.currentHeight,

  },

  topo:{

    flexDirection:'row',

    justifyContent:'flex-end',

    padding:10,

    gap:15,

  },

  card:{

    margin:15,

    alignItems:'center',

  },

  imagem:{

    width:320,

    height:250,

    borderRadius:10,

  },

  fechar:{

    position:'absolute',

    zIndex:1,

    top:5,

    left:10,

    backgroundColor:'white',

    borderRadius:20,

  }

});