import React from 'react';
import {
  SafeAreaView,
  View,
  Button,
  Linking,
  Alert,
  StyleSheet,
} from 'react-native';

export default function App() {

  const ligar = async () => {

    const telefone = 'tel:123456789';

    const podeAbrir = await Linking.canOpenURL(telefone);

    if (podeAbrir) {
      Linking.openURL(telefone);
    } else {
      Alert.alert(
        'Erro',
        'Não foi possível abrir o aplicativo de telefone.'
      );
    }

  };

  return (

    <SafeAreaView style={styles.container}>

      <View>

        <Button
          title="Ligar"
          onPress={ligar}
        />

      </View>

    </SafeAreaView>

  );

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

});