import React from 'react';
import {
  SafeAreaView,
  View,
  Button,
  Linking,
  Alert,
  StyleSheet,
} from 'react-native';

export default function App() {

  const abrirInstagram = async () => {

    const url = 'https://www.instagram.com/etec_sjc195';

    const podeAbrir = await Linking.canOpenURL(url);

    if (podeAbrir) {
      Linking.openURL(url);
    } else {
      Alert.alert(
        'Erro',
        'Não foi possível abrir o Instagram.'
      );
    }

  };

  return (

    <SafeAreaView style={styles.container}>

      <View>

        <Button
          title="Abrir Instagram da ETEC"
          onPress={abrirInstagram}
        />

      </View>

    </SafeAreaView>

  );

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

});