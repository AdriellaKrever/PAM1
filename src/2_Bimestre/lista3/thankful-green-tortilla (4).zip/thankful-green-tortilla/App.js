import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
} from 'react-native';

import * as Contacts from 'expo-contacts';
import Constants from 'expo-constants';

export default function App() {

  const [contatos, setContatos] = useState([]);
  const [permissao, setPermissao] = useState(null);

  useEffect(() => {

    async function carregarContatos() {

      const { status } = await Contacts.requestPermissionsAsync();

      setPermissao(status === 'granted');

      if (status === 'granted') {

        const { data } = await Contacts.getContactsAsync({

          fields: [
            Contacts.Fields.FirstName,
            Contacts.Fields.PhoneNumbers,
          ],

        });

        if (data.length > 0) {
          setContatos(data);
        }

      }

    }

    carregarContatos();

  }, []);

  if (permissao === null) {
    return <View />;
  }

  if (permissao === false) {
    return (
      <View style={styles.container}>
        <Text style={styles.texto}>
          Permissão negada.
        </Text>
      </View>
    );
  }

  return (

    <View style={styles.container}>

      <FlatList
        data={contatos}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (

          <View style={styles.item}>

            <Text style={styles.nome}>
              {item.firstName}
            </Text>

            {item.phoneNumbers &&
              item.phoneNumbers.map((telefone, index) => (

                <Text
                  key={index}
                  style={styles.numero}
                >
                  {telefone.number}
                </Text>

              ))}

          </View>

        )}
      />

    </View>

  );

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#222',
  },

  item: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#555',
  },

  nome: {
    color: 'yellow',
    fontSize: 18,
  },

  numero: {
    color: 'white',
  },

  texto: {
    color: 'white',
    textAlign: 'center',
    marginTop: 20,
  },

});