import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { Ionicons } from "@expo/vector-icons";


import Home from "./screens/Home";
import Um from "./screens/Um";
import Dois from "./screens/Dois";
import Tres from "./screens/Tres";
import quatro from "./screens/quatro";
import Cinco from "./screens/Cinco";
import Seis from "./screens/Seis";
import Sete from "./screens/Sete";
import Oito from "./screens/Oito";
import Nove from "./screens/Nove";
import Dez from "./screens/Dez";
import Onze from "./screens/Onze";

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">

        <Drawer.Screen
          name="Home"
          component={Home}
        />

        <Drawer.Screen
          name="Um"
          component={Um}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />

        <Drawer.Screen
          name="Dois"
          component={Dois}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />

        <Drawer.Screen
          name="Tres"
          component={Tres}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />
        <Drawer.Screen
          name="Quatro"
          component={quatro}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />
        <Drawer.Screen
          name="Cinco"
          component={Cinco}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />
        <Drawer.Screen
          name="Seis"
          component={Seis}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />
        <Drawer.Screen
          name="Sete"
          component={Sete}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />

        <Drawer.Screen
          name="Oito"
          component={Oito}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />
        <Drawer.Screen
          name="Nove"
          component={Nove}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />
        <Drawer.Screen
          name="Dez"
          component={Dez}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />

        <Drawer.Screen
          name="Onze"
          component={Onze}
           options={{
    drawerIcon: ({ color, size }) => (
      <Ionicons
        name="home"
        color={color}
        size={size}
      />
    ),
  }}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
} 