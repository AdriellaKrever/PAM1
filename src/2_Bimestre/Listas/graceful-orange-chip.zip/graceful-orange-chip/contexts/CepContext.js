import React, { createContext, useState } from 'react';
import api from '../services/api';

export const CepContext = createContext({});

export function CepProvider({ children }) {

  const [endereco, setEndereco] = useState(null);

  async function buscarCep(cep) {

    try {

      const response = await api.get(`/${cep}/json/`);

      setEndereco(response.data);

    } catch (error) {

      alert("Erro ao consultar CEP");

    }

  }

  return (

    <CepContext.Provider
      value={{
        endereco,
        buscarCep
      }}
    >
      {children}
    </CepContext.Provider>

  );

}