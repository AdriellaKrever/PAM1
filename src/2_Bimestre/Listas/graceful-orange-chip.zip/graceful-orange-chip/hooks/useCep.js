import { useContext } from 'react';
import { CepContext } from '../contexts/CepContext';

export default function useCep() {
  return useContext(CepContext);
}