import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet
} from 'react-native';

import useCep from '../hooks/useCep';

export default function HomeScreen() {

  const [cep, setCep] = useState('');

  const { endereco, buscarCep } = useCep();

  return (

    <View style={styles.container}>

      <Text style={styles.label}>
        CEP
      </Text>

      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={cep}
        onChangeText={setCep}
        placeholder="Digite o CEP"
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={() => buscarCep(cep)}
      >

        <Text style={styles.textoBotao}>
          Obter
        </Text>

      </TouchableOpacity>

      {
        endereco && (

          <View style={styles.resultado}>

            <Text>
              Logradouro: {endereco.logradouro}
            </Text>

            <Text>
              Bairro: {endereco.bairro}
            </Text>

            <Text>
              Localidade: {endereco.localidade}
            </Text>

            <Text>
              UF: {endereco.uf}
            </Text>

          </View>

        )
      }

    </View>

  );

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#333'
  },

  label: {
    color: '#fff',
    marginBottom: 5
  },

  input: {
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15
  },

  botao: {
    backgroundColor: 'yellow',
    padding: 12,
    borderRadius: 5,
    alignItems: 'center'
  },

  textoBotao: {
    fontWeight: 'bold'
  },

  resultado: {
    marginTop: 20
  }

});