import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";


import Home from "./screens/Home";
import Um from "./screens/Um";
import Dois from "./screens/Dois";
import Tres from "./screens/Tres";
import quatro from "./screens/quatro";
import Cinco from "./screens/Cinco";
import Seis from "./screens/Seis";
import Sete from "./screens/Sete";
import Oito from "./screens/Oito";
import Nove from "./screens/Nove";
import Dez from "./screens/Dez";
import Onze from "./screens/Onze";

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">

        <Drawer.Screen
          name="Home"
          component={Home}
        />

        <Drawer.Screen
          name="Um"
          component={Um}
        />

        <Drawer.Screen
          name="Dois"
          component={Dois}
        />

        <Drawer.Screen
          name="Tres"
          component={Tres}
        />
        <Drawer.Screen
          name="Quatro"
          component={quatro}
        />
        <Drawer.Screen
          name="Cinco"
          component={Cinco}
        />
        <Drawer.Screen
          name="Seis"
          component={Seis}
        />
        <Drawer.Screen
          name="Sete"
          component={Sete}
        />

        <Drawer.Screen
          name="Oito"
          component={Oito}
        />
        <Drawer.Screen
          name="Nove"
          component={Nove}
        />
        <Drawer.Screen
          name="Dez"
          component={Dez}
        />

        <Drawer.Screen
          name="Onze"
          component={Onze}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
} 