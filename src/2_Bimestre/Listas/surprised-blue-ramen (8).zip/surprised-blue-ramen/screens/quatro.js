import { View, Text } from 'react-native';

export default function Quatro() {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <Text>Tela Dois</Text>
    </View>
  );
}