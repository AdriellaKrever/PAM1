import { View, Text } from "react-native";

export default function Um() {
  return (
    <View
      style={{
        flex:1,
        justifyContent:"center",
        alignItems:"center"
      }}
    >
      <Text>Tela Um</Text>
    </View>
  );
}