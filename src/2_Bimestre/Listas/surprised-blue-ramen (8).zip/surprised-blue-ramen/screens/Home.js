
import {
  SafeAreaView,
  TouchableOpacity,
  Text,
  Image,
  View,
  StyleSheet,
} from "react-native";

export default function Home({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>

      <Image
        source={{
          uri: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Logo_ETEC.svg/512px-Logo_ETEC.svg.png",
        }}
        style={styles.logo}
      />

      <View style={styles.row}>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Um")}
        >
          <Text>Um</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Dois")}
        >
          <Text>Dois</Text>
        </TouchableOpacity>

      </View>

      <View style={styles.row}>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Tres")}
        >
          <Text>Tres</Text>
        </TouchableOpacity>

                <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("quatro")}
        >
          <Text>quatro</Text>
        </TouchableOpacity>

      </View>

            <View style={styles.row}>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Cinco")}
        >
          <Text>Cinco</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Seis")}
        >
          <Text>Seis</Text>
        </TouchableOpacity>

      </View>

            <View style={styles.row}>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Sete")}
        >
          <Text>Sete</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Oito")}
        >
          <Text>Oito</Text>
        </TouchableOpacity>

      </View>

            <View style={styles.row}>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Nove")}
        >
          <Text>Nove</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("Dez")}
        >
          <Text>Dez</Text>
        </TouchableOpacity>

      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  logo: {
    width: 140,
    height: 140,
    marginBottom: 30,
  },

  row: {
    flexDirection: "row",
    marginBottom: 15,
  },

  button: {
    backgroundColor: "#ddd",
    padding: 20,
    marginHorizontal: 10,
    borderRadius: 10,
    width: 120,
    alignItems: "center",
  },
});