import { View, Text } from "react-native";

export default function Tres() {
  return (
    <View
      style={{
        flex:1,
        justifyContent:"center",
        alignItems:"center"
      }}
    >
      <Text>Tela Tres</Text>
    </View>
  );
}