import React, { createContext, useState } from 'react';
import api from '../services/api';

export const CepContext = createContext({});

export function CepProvider({ children }) {

  const [endereco, setEndereco] = useState(null);
  const [lista, setLista] = useState([]);
  const [erro, setErro] = useState(false);

  async function buscarCep(cep) {

    try {

      const response = await api.get(`/${cep}/json/`);

      if (response.data.erro) {
        setErro(true);
        setEndereco(null);
        return;
      }

      setErro(false);
      setEndereco(response.data);

      setLista([...lista, response.data]);

    } catch {

      alert("Erro ao consultar CEP");

    }

  }

  return (

    <CepContext.Provider
      value={{
        endereco,
        buscarCep,
        lista,
        erro
      }}
    >
      {children}
    </CepContext.Provider>

  );

}