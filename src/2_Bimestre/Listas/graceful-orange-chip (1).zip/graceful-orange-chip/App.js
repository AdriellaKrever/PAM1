import 'react-native-gesture-handler';

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';

import HomeScreen from './screens/HomeScreen';
import ListaScreen from './screens/ListaScreen';

import { CepProvider } from './contexts/CepContext';

const Drawer = createDrawerNavigator();

export default function App(){

  return(

    <CepProvider>

      <NavigationContainer>

        <Drawer.Navigator>

          <Drawer.Screen
            name="ViaCEP"
            component={HomeScreen}
          />

          <Drawer.Screen
            name="Consultas de CEP"
            component={ListaScreen}
          />

        </Drawer.Navigator>

      </NavigationContainer>

    </CepProvider>

  );

}