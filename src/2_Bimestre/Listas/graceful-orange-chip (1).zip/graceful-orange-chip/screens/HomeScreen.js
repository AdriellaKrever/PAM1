import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet
} from 'react-native';

import useCep from '../hooks/useCep';

export default function HomeScreen() {

  const [cep, setCep] = useState('');

  const { endereco, buscarCep, erro } = useCep();

  return (

    <View style={styles.container}>

      <Text style={styles.label}>CEP</Text>

      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={cep}
        onChangeText={setCep}
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={() => buscarCep(cep)}
      >
        <Text style={styles.textoBotao}>Obter</Text>
      </TouchableOpacity>

      {erro && (
        <Text style={styles.erro}>
          CEP inválido
        </Text>
      )}

      {endereco && (

        <View style={styles.resultado}>

          <Text>Logradouro: {endereco.logradouro}</Text>

          <Text>Localidade: {endereco.localidade}</Text>

          <Text>UF: {endereco.uf}</Text>

        </View>

      )}

    </View>

  );

}

const styles = StyleSheet.create({

  container: {
    flex:1,
    justifyContent:'center',
    backgroundColor:'#333',
    padding:20
  },

  label:{
    color:'#fff',
    marginBottom:5
  },

  input:{
    backgroundColor:'#fff',
    padding:10,
    borderRadius:5
  },

  botao:{
    marginTop:10,
    backgroundColor:'yellow',
    padding:12,
    borderRadius:5,
    alignItems:'center'
  },

  textoBotao:{
    fontWeight:'bold'
  },

  erro:{
    color:'white',
    marginTop:10
  },

  resultado:{
    marginTop:20
  }

});