import React from 'react';

import {
  View,
  Text,
  ScrollView,
  StyleSheet
} from 'react-native';

import useCep from '../hooks/useCep';

export default function ListaScreen(){

  const { lista } = useCep();

  return(

    <ScrollView style={styles.container}>

      {

        lista.map((item,index)=>(

          <View
            key={index}
            style={styles.card}
          >

            <Text>
              Logradouro: {item.logradouro}
            </Text>

            <Text>
              Localidade: {item.localidade}
            </Text>

            <Text>
              UF: {item.uf}
            </Text>

          </View>

        ))

      }

    </ScrollView>

  );

}

const styles = StyleSheet.create({

  container:{
    flex:1,
    backgroundColor:'#333',
    padding:15
  },

  card:{
    borderBottomWidth:1,
    borderBottomColor:'#777',
    paddingVertical:10
  }

});